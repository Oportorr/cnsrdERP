<?php
define('SERVICE', 'http://provider.ultimatekode.com/geo/90/check.php');
define('APPVER', '?v=5.01');
define('UPDATE_SERVICE', 'http://provider.ultimatekode.com/updates/');// change it to on for exclusive
